module.exports = function (api) {
  api.cache(true);
  return {
    // babel-preset-expo(SDK 57)가 react-native-worklets/plugin을 자동으로 추가하므로
    // Reanimated용 플러그인을 따로 명시하지 않는다.
    presets: ['babel-preset-expo'],
  };
};
